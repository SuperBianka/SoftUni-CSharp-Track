﻿using System;
using System.Collections.Generic;

namespace _01.ListyIterator
{
    public class ListyIterator<T>
    {
        private List<T> itemsCollection;
        private int currentIndex;

        public ListyIterator(List<T> items)
        {
            this.itemsCollection = items;
            currentIndex = 0;
        }

        public bool Move()
        {
            if (this.HasNext())
            {
                this.currentIndex++;

                return true;
            }

            return false;
        }

        public bool HasNext() => this.currentIndex < this.itemsCollection.Count - 1;

        public void Print()
        {
            if (this.itemsCollection.Count == 0)
            {
                throw new InvalidOperationException("Invalid Operation!");
            }
            else
            {
                Console.WriteLine(this.itemsCollection[this.currentIndex]);
            }
        }
    }
}
