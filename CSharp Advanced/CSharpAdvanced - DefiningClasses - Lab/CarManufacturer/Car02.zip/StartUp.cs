﻿using System;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Car car = new Car();

            car.Make = "Nissan";
            car.Model = "Rogue";
            car.Year = 2020;

            //Console.WriteLine($"Make: {car.Make}\nModel: {car.Model}\nYear: {car.Year}");

            car.FuelQuantity = 350;
            car.FuelConsumption = 10;
            car.Drive(20);
            Console.WriteLine(car.WhoAmI());

        }
    }
}
