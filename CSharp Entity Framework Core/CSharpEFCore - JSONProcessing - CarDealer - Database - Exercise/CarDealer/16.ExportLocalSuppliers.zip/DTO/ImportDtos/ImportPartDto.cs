﻿namespace CarDealer.DTO.ImportDtos
{
    public class ImportPartDto
    {
        public string Name { get; set; }

        public decimal Price { get; set; }

        public int Quantity { get; set; }

        public int SupplierId { get; set; }
    }
}
