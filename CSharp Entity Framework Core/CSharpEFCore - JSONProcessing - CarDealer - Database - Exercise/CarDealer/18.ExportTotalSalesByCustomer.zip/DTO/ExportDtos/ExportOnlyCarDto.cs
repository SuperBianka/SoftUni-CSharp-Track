﻿namespace CarDealer.DTO.ExportDtos
{
    public class ExportOnlyCarDto
    {
        public string Make { get; set; }

        public string Model { get; set; }

        public long TravelledDistance { get; set; }
    }
}
