﻿namespace SoftJail.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-ORD5BUV\SQLEXPRESS;Database=SoftJail;Trusted_Connection=True";
    }
}
