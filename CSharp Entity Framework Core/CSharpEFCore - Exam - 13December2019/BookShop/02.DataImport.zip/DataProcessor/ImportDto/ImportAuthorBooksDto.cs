﻿namespace BookShop.DataProcessor.ImportDto
{
    public class ImportAuthorBooksDto
    {
        public int? Id { get; set; }
    }
}
