﻿namespace ProductShop.ImportDtos
{
    public class ImportCategoryDto
    {
        public string Name { get; set; }
    }
}
