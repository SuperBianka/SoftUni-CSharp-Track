﻿namespace ProductShop.DataTransferObject
{
    public class ImportUserDto
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public int? Age { get; set; }
    }
}
