﻿namespace P01_StudentSystem.Data.Models.Enumerations
{
    public enum ContentType
    {
        Application = 1,
        Pdf = 2,
        Zip = 3
    }
}
