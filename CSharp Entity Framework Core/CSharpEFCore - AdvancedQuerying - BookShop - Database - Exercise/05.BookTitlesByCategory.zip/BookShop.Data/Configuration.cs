﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString 
            => @"Server=DESKTOP-ORD5BUV\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
