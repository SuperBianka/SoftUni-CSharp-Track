﻿using System;

namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!"); 
            Elf elf = new Elf("Flu", 3);
            Console.WriteLine(elf);
        }
    }
}