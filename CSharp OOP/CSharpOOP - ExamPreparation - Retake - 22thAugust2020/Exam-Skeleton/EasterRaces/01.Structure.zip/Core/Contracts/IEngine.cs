﻿namespace EasterRaces.Core.Contracts
{
    class IEngine
    {
    }
}
