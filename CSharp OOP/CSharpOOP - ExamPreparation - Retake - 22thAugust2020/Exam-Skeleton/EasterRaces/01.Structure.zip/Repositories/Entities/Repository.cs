﻿using System.Collections.Generic;
using System.Linq;
using EasterRaces.Repositories.Contracts;

namespace EasterRaces.Repositories.Entities
{
    public abstract class Repository<T> : IRepository<T>
    {
        protected Repository()
        {
            this.Models = new List<T>();
        }

        public ICollection<T> Models { get; }

        public void Add(T model) => this.Models.Add(model);

        public IReadOnlyCollection<T> GetAll() => this.Models as IReadOnlyCollection<T>;

        public T GetByName(string name) => this.Models.FirstOrDefault(m => m.GetType().Name == name);

        public bool Remove(T model) => this.Models.Remove(model);
    }
}
