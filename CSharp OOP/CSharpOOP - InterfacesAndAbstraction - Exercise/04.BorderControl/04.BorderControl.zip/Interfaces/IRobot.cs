﻿namespace _04.BorderControl.Interfaces
{
    public interface IRobot : IIdentifiable
    {
        string Model { get; }
    }
}
