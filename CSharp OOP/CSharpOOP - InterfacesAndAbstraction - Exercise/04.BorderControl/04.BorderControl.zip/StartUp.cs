﻿using System;
using System.Collections.Generic;
using System.Linq;
using _04.BorderControl.Interfaces;

namespace _04.BorderControl
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<IIdentifiable> identifiables = new List<IIdentifiable>();

            string line = string.Empty;

            while ((line = Console.ReadLine()) != "End")
            {
                string[] lineParts = line
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();

                if (lineParts.Length == 3)
                {
                    string name = lineParts[0];
                    int age = int.Parse(lineParts[1]);
                    string id = lineParts[2];

                    Citizen citizen = new Citizen(name, age, id);
                    identifiables.Add(citizen);
                }
                else if (lineParts.Length == 2)
                {
                    string model = lineParts[0];
                    string id = lineParts[1];

                    Robot robot = new Robot(model, id);
                    identifiables.Add(robot);
                }
            }

            string fakeIdsLastDigits = Console.ReadLine();

            List<IIdentifiable> filteredList = identifiables.Where(i => i.Id.EndsWith(fakeIdsLastDigits)).ToList();

            foreach (IIdentifiable identifiable in filteredList)
            {
                Console.WriteLine(identifiable.Id);
            }
        }
    }
}
