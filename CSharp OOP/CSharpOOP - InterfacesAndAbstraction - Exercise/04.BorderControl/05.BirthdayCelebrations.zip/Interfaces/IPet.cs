﻿namespace _04.BorderControl.Interfaces
{
    public interface IPet : IBirthable
    {
        string Name { get; }
    }
}
