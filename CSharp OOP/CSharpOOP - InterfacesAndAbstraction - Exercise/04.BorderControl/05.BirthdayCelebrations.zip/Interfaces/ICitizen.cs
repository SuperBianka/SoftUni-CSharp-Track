﻿namespace _04.BorderControl.Interfaces
{
    public interface ICitizen : IIdentifiable, IBirthable
    {
        string Name { get; }

        int Age { get; }
    }
}
