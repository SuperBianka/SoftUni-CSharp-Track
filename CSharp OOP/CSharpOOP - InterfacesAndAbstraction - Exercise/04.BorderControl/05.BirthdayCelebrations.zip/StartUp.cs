﻿using System;
using System.Collections.Generic;
using System.Linq;
using _04.BorderControl.Interfaces;
using _04.BorderControl.Models;

namespace _04.BorderControl
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<IBirthable> birthables = new List<IBirthable>();

            string line = string.Empty;

            while ((line = Console.ReadLine()) != "End")
            {
                string[] lineParts = line
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();

                string type = lineParts[0];

                if (type == nameof(Citizen))
                {
                    string name = lineParts[1];
                    int age = int.Parse(lineParts[2]);
                    string id = lineParts[3];
                    string birthdate = lineParts[4];

                    Citizen citizen = new Citizen(name, age, id, birthdate);
                    birthables.Add(citizen);
                }
                else if (type == nameof(Pet))
                {
                    string name = lineParts[1];
                    string birthdate = lineParts[2];

                    Pet pet = new Pet(name, birthdate);
                    birthables.Add(pet);
                }
            }

            string specificYear = Console.ReadLine();

            List<IBirthable> filteredList = birthables.Where(b => b.Birthdate.EndsWith(specificYear)).ToList();

            foreach (IBirthable birthable in filteredList)
            {
                Console.WriteLine(birthable.Birthdate);
            } 
        }
    }
}
