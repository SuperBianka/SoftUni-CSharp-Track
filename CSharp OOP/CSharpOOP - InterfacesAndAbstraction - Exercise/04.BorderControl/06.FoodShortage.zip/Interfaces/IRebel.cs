﻿namespace _04.BorderControl.Interfaces
{
    public interface IRebel : ICitizen
    {
        string Group { get; }
    }
}
