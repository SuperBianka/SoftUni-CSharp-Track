﻿namespace _04.BorderControl.Interfaces
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
