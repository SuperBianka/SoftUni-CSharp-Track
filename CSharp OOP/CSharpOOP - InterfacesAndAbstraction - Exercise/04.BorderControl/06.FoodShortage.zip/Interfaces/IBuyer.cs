﻿namespace _04.BorderControl.Interfaces
{
    public interface IBuyer
    {
        int Food { get; }

        void BuyFood();
    }
}
