﻿namespace _04.BorderControl
{
    public interface IBirthable
    {
        string Birthdate { get; }
    }
}
