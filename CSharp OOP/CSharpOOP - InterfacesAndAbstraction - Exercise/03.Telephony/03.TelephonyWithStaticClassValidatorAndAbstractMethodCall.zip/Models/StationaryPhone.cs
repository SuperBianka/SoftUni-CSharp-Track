﻿namespace _03.Telephony.Models
{
    public class StationaryPhone : Phone
    {
        public override string Call(string phoneNumber)
        {
            Validator.ThrowIfNumberIsInvalid(phoneNumber);

            return $"Dialing... {phoneNumber}";
        }
    }
}
