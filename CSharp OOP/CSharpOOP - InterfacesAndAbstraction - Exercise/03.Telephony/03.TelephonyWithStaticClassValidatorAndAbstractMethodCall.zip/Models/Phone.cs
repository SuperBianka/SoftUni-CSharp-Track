﻿using _03.Telephony.Interfaces;

namespace _03.Telephony
{
    public abstract class Phone : ICallable
    {
        public abstract string Call(string phoneNumber);
    }
}
