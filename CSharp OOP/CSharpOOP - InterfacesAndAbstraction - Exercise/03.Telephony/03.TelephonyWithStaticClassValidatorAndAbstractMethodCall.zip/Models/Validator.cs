﻿using System.Linq;
using _03.Telephony.Exceptions;

namespace _03.Telephony.Models
{
    public static class Validator
    {
        public static void ThrowIfNumberIsInvalid(string phoneNumber)
        {
            if (!phoneNumber.All(x => char.IsDigit(x)))
            {
                throw new InvalidPhoneNumberException();
            }
        }
    }
}
