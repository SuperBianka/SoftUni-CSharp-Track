﻿namespace _03.Telephony.Interfaces
{
    public interface IBrowsable
    {
        string Browse(string url);
    }
}
