﻿namespace _07.MilitaryElite.Interfaces
{
    public interface ISoldier
    {
        string Id { get; }

        string FirstName { get; }

        string LastName { get; }
    }
}
