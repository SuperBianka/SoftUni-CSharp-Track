﻿namespace _07.MilitaryElite.Enumerations
{
    public enum MissionState
    {
        inProgress,
        Finished
    }
}
